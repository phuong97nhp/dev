function View() {
    return <div>
        <h1>Giới thiệu</h1>
        <p>Vui lòng liên hệ với bộ phận hỗ trợ kinh doanh để được cung cấp tài khoản kiểm thử.</p>
        <code className="customCode">
            Liện hệ Zalo : 0962 640 068 (Nguyễn Hoàng Phương)
        </code>
        {/* <textarea className="customCode" row="5">

        </textarea>
        <div className="customLink">
        http://localhost:3001/about
        </div> */}
    </div>
}
export default View;