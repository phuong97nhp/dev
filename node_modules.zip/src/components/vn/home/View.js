function View() {
    return <div>
        <h1>LIÊN HỆ</h1>
        <div className="customText">
        CÔNG TY CỔ PHẦN CHUYỂN PHÁT NHANH MUÔN PHƯƠNG<br/>

        Địa chỉ: 64-66 Thăng Long, P. 2, Q. Tân Bình,Tp. Hồ Chí Minh (TPHCM) <br/>

        Hotline (028) 62968551
        </div>
    </div>
}
export default View;