import $ from "jquery";

function Menu(props) {

    return <div className="menuChild">
        <h5 id="menuTitle">&nbsp;</h5>
        <div id="menuContent">

        </div>
    </div>
}

export default Menu;