function View() {
    return <div>
        <h1 className="text-center">Không tìm thấy trang</h1>
    </div>
}
export default View;