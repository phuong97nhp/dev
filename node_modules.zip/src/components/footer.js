function Footer() {
    return <footer className="bg-dark pb-1">
        <p className="text-center text-white">Bản quyền © 2022 Azexpress.</p>
    </footer>;
}

export default Footer;